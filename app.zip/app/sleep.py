import time

# sleep method, makes main code a little more readable
def sleep(n):
	time.sleep (n)